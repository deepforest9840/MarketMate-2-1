package com.example.mainshop;

public class random {
/*
    public void search() {
        String searchString = searchField.getText();
        customerTable.getItems().clear();
        for (CustomerData customer : customerList) {
            if (customer.getName().contains(searchString) ||
                    customer.getAddress().contains(searchString) ||
                    customer.getPhone().contains(searchString)) {
                customerTable.getItems().add(customer);
            }
        }
    }
*/

}
